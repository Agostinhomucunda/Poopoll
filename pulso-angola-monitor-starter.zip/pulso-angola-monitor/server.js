import 'dotenv/config';
import express from 'express';
import cron from 'node-cron';
import Database from 'better-sqlite3';
import Parser from 'rss-parser';
import * as cheerio from 'cheerio';
import OpenAI from 'openai';
import crypto from 'node:crypto';
import fs from 'node:fs';

const app = express();
app.use(express.json({limit:'1mb'}));
app.use(express.static('public'));
const db = new Database('pulso.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS opportunities (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 fingerprint TEXT UNIQUE NOT NULL,
 title TEXT NOT NULL, category TEXT NOT NULL, organization TEXT,
 description TEXT, province TEXT, municipality TEXT,
 application_deadline TEXT, source_name TEXT, source_url TEXT NOT NULL,
 application_url TEXT, official_website TEXT,
 image_url TEXT, image_type TEXT, image_note TEXT, image_source_page TEXT,
 logo_url TEXT, logo_type TEXT, logo_note TEXT,
 status TEXT DEFAULT 'pending', exported_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 checked_at TEXT
);
CREATE TABLE IF NOT EXISTS exports (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 export_key TEXT UNIQUE NOT NULL,
 item_ids TEXT NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 acknowledged_at TEXT
);
`);
const parser = new Parser();
const openai = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
const sources = JSON.parse(fs.readFileSync('./sources.json','utf8'));
const INSIGNIA = 'https://governo.gov.ao/public/app-assets/img/simbolos/insignia.png';
const FALLBACK_IMAGES = {
 bolsas:'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1200',
 empregos:'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=1200',
 concursos:'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1200',
 estagios:'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200',
 formacao:'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=1200',
 programas:'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?w=1200'
};
const norm = s => (s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();
const fingerprint = x => crypto.createHash('sha256').update(norm(x.title)+'|'+norm(x.organization)+'|'+norm(x.source_url)).digest('hex');

function categoryOf(text) {
 const t=norm(text);
 if (/bolsa|scholarship|fellowship/.test(t)) return 'bolsas';
 if (/concurso publico|recrutamento|concurso de ingresso/.test(t)) return 'concursos';
 if (/estagio|internship/.test(t)) return 'estagios';
 if (/formacao|curso|capacitacao/.test(t)) return 'formacao';
 if (/programa/.test(t)) return 'programas';
 return 'empregos';
}
async function fetchPage(url) {
 const r=await fetch(url,{headers:{'user-agent':'PULSO-Angola-Monitor/1.0 (+admin contact)'},signal:AbortSignal.timeout(18000)});
 if(!r.ok) throw new Error(`HTTP ${r.status}`);
 return await r.text();
}
async function extractWithAI(text,url,sourceName) {
 if(!openai) return null;
 const completion=await openai.chat.completions.create({
  model:process.env.OPENAI_MODEL||'gpt-4.1-mini',
  response_format:{type:'json_object'},
  messages:[
   {role:'system',content:'És um assistente de pesquisa de oportunidades em Angola. Extrai apenas factos explícitos. Não inventes datas, vagas, valores, entidades ou links. Só considera bolsas, empregos, concursos públicos, estágios, formação e programas relevantes para cidadãos/residentes em Angola. Se não for uma oportunidade concreta, devolve {"relevant":false}. Devolve JSON com relevant,title,category,organization,description,province,municipality,application_deadline,application_url,official_website. category deve ser bolsas, empregos, concursos, estagios, formacao ou programas. Se não houver prazo, usa null. Se não houver candidatura explícita, application_url null.'},
   {role:'user',content:`Fonte: ${sourceName}\nURL: ${url}\nConteúdo:\n${text.slice(0,14000)}`}
  ]
 });
 try { return JSON.parse(completion.choices[0].message.content); } catch { return null; }
}
async function saveCandidate(candidate, source, pageUrl, html) {
 if(!candidate?.relevant || !candidate.title) return false;
 const category=['bolsas','empregos','concursos','estagios','formacao','programas'].includes(candidate.category)?candidate.category:categoryOf(candidate.title+' '+candidate.description);
 const $=cheerio.load(html);
 const og=$('meta[property="og:image"]').attr('content') || $('meta[name="twitter:image"]').attr('content');
 const logo=$('meta[property="og:logo"]').attr('content') || $('link[rel*="icon"]').attr('href');
 const abs=(u)=>{try{return u?new URL(u,pageUrl).href:null}catch{return null}};
 const image=abs(og)||FALLBACK_IMAGES[category]||FALLBACK_IMAGES.programas;
 const logoUrl=abs(logo)||INSIGNIA;
 const fp=fingerprint({...candidate,source_url:pageUrl});
 const status=String(process.env.AUTO_PUBLISH).toLowerCase()==='true'?'published':'pending';
 const stmt=db.prepare(`INSERT OR IGNORE INTO opportunities
 (fingerprint,title,category,organization,description,province,municipality,application_deadline,source_name,source_url,application_url,official_website,image_url,image_type,image_note,image_source_page,logo_url,logo_type,logo_note,status,checked_at)
 VALUES (@fingerprint,@title,@category,@organization,@description,@province,@municipality,@application_deadline,@source_name,@source_url,@application_url,@official_website,@image_url,@image_type,@image_note,@image_source_page,@logo_url,@logo_type,@logo_note,@status,@checked_at)`);
 const result=stmt.run({
  fingerprint:fp,title:candidate.title,category,organization:candidate.organization||source.name,
  description:candidate.description||'',province:candidate.province||null,municipality:candidate.municipality||null,
  application_deadline:candidate.application_deadline||null,source_name:source.name,source_url:pageUrl,
  application_url:candidate.application_url||null,official_website:candidate.official_website||source.url,
  image_url:image,image_type:og?'official':'illustrative',
  image_note:og?'Imagem encontrada nos metadados da página.':'Imagem temática ilustrativa; não representa necessariamente o anúncio.',
  image_source_page:pageUrl,logo_url:logoUrl,logo_type:logo?'detected':'national_emblem_fallback',
  logo_note:logo?'Ícone/logótipo detectado na página; confirmar se pertence à entidade.':'Insígnia da República de Angola usada apenas como alternativa.',
  status,checked_at:new Date().toISOString()
 });
 return result.changes>0;
}
async function scanSource(source) {
 try {
  const html=await fetchPage(source.url);
  const $=cheerio.load(html);
  const links=new Set([source.url]);
  $('a[href]').each((_,a)=>{
   const href=$(a).attr('href'); const label=$(a).text();
   if(!href || !/bolsa|emprego|concurso|estagio|formacao|oportunidade|recrutamento|scholarship/i.test(label+' '+href)) return;
   try { const u=new URL(href,source.url); if(u.protocol==='https:' && u.hostname===new URL(source.url).hostname) links.add(u.href); } catch {}
  });
  const selected=[...links].slice(0,Number(process.env.MAX_ITEMS_PER_SOURCE||30));
  for(const url of selected) {
   try {
    const page= url===source.url?html:await fetchPage(url);
    const p=cheerio.load(page);
    const text=p('body').text().replace(/\s+/g,' ').trim();
    if(text.length<250) continue;
    const candidate=await extractWithAI(text,url,source.name);
    if(candidate) await saveCandidate(candidate,source,url,page);
   } catch(e) { console.error('Página ignorada',url,e.message); }
  }
  console.log('Fonte verificada:',source.name);
 } catch(e) { console.error('Falha na fonte',source.name,e.message); }
}
async function scanAll() { for(const s of sources) await scanSource(s); }
const auth=(req,res,next)=>{
 const token=req.headers['x-admin-token']||req.query.token;
 if(!process.env.ADMIN_TOKEN || token!==process.env.ADMIN_TOKEN) return res.status(401).json({error:'Acesso administrativo não autorizado'});
 next();
};
app.get('/api/health',(_,res)=>res.json({ok:true,service:'PULSO Angola Monitor'}));
app.get('/api/opportunities',(req,res)=>{
 const {category='all',status='all',q=''}=req.query;
 let sql='SELECT * FROM opportunities WHERE 1=1',args=[];
 if(category!=='all'){sql+=' AND category=?';args.push(category)}
 if(status!=='all'){sql+=' AND status=?';args.push(status)}
 if(q){sql+=' AND (title LIKE ? OR organization LIKE ? OR description LIKE ?)';args.push(`%${q}%`,`%${q}%`,`%${q}%`)}
 sql+=' ORDER BY created_at DESC';
 res.json(db.prepare(sql).all(...args));
});
app.post('/api/scan',auth,async(req,res)=>{res.json({started:true}); scanAll();});
app.post('/api/opportunities/:id/publish',auth,(req,res)=>{
 const r=db.prepare("UPDATE opportunities SET status='published' WHERE id=?").run(req.params.id);
 res.json({updated:r.changes});
});
app.post('/api/opportunities/:id/archive',auth,(req,res)=>{
 const r=db.prepare("UPDATE opportunities SET status='archived' WHERE id=?").run(req.params.id);
 res.json({updated:r.changes});
});
app.post('/api/export',auth,(req,res)=>{
 const ids=db.prepare("SELECT id FROM opportunities WHERE status='published' AND exported_at IS NULL ORDER BY created_at").all().map(x=>x.id);
 if(!ids.length) return res.json({export_id:null,count:0,items:[]});
 const rows=db.prepare(`SELECT * FROM opportunities WHERE id IN (${ids.map(()=>'?').join(',')})`).all(...ids);
 const key=crypto.randomUUID();
 db.prepare('INSERT INTO exports(export_key,item_ids) VALUES(?,?)').run(key,JSON.stringify(ids));
 res.json({export_id:key,count:rows.length,items:rows.map(({fingerprint,...x})=>x)});
});
app.post('/api/export/:key/ack',auth,(req,res)=>{
 const exp=db.prepare('SELECT * FROM exports WHERE export_key=?').get(req.params.key);
 if(!exp) return res.status(404).json({error:'Exportação não encontrada'});
 const ids=JSON.parse(exp.item_ids);
 const tx=db.transaction(()=>{
  db.prepare('UPDATE opportunities SET exported_at=CURRENT_TIMESTAMP WHERE id IN ('+ids.map(()=>'?').join(',')+')').run(...ids);
  db.prepare('UPDATE exports SET acknowledged_at=CURRENT_TIMESTAMP WHERE export_key=?').run(req.params.key);
 });
 tx(); res.json({acknowledged:true,count:ids.length});
});
app.get('/api/stats',(_,res)=>res.json({
 total:db.prepare('SELECT count(*) n FROM opportunities').get().n,
 pending:db.prepare("SELECT count(*) n FROM opportunities WHERE status='pending'").get().n,
 published:db.prepare("SELECT count(*) n FROM opportunities WHERE status='published' AND exported_at IS NULL").get().n,
 exported:db.prepare('SELECT count(*) n FROM opportunities WHERE exported_at IS NOT NULL').get().n
}));
const minutes=Math.max(5,Number(process.env.SCAN_INTERVAL_MINUTES||30));
cron.schedule(`*/${minutes} * * * *`,()=>scanAll());
const port=Number(process.env.PORT||3000);
app.listen(port,()=>{console.log(`PULSO activo na porta ${port}`);});
