# PULSO Angola — Monitor de Oportunidades

Aplicação inicial para pesquisar, organizar, rever e exportar oportunidades de Angola.

## O que faz
- Pesquisa automática em fontes configuradas em `sources.json`.
- Executa uma ronda periódica (por defeito, a cada 30 minutos) e permite pesquisa manual.
- Classifica em bolsas, empregos, concursos, estágios, formação e programas.
- Guarda tudo numa base SQLite persistente e usa uma impressão digital para impedir duplicados.
- Mostra oportunidades por rever antes de publicar.
- Preserva registos exportados; apenas deixa de os incluir na próxima exportação. Assim, o sistema não perde o histórico nem volta a exportar o mesmo registo.
- Exporta JSON com descrição, fonte, candidatura, imagem e logótipo.
- Usa imagem temática ilustrativa quando não encontra imagem na página e identifica-a como ilustrativa.
- Usa a Insígnia da República de Angola como fallback de logótipo quando não detecta um logótipo/ícone; a interface identifica esse caso.

## Requisitos
- Node.js 20 ou superior.
- Uma base de dados persistente (o SQLite `pulso.sqlite`).
- Chave da API OpenAI para extracção/classificação automática. Sem a chave, o sistema continua a funcionar mas não consegue interpretar os anúncios automaticamente.

## Instalação local
1. Descompacte o ZIP.
2. Copie `.env.example` para `.env`.
3. Defina `ADMIN_TOKEN` e `OPENAI_API_KEY`.
4. Execute `npm install`.
5. Execute `npm start`.
6. Abra `http://localhost:3000`.

Introduza o `ADMIN_TOKEN` no campo do painel para pesquisar, aprovar e exportar.

## Hospedagem contínua
Use um VPS ou serviço de contentores que mantenha o processo Node activo e ofereça disco persistente. Não use alojamento apenas estático nem funções serverless efémeras: o agendador e a base SQLite precisam de permanecer activos/persistentes. Configure:
- comando de arranque: `npm start`
- armazenamento persistente para `pulso.sqlite`
- variáveis de ambiente de `.env.example`
- HTTPS e backups regulares da base de dados

## Como funciona a exportação sem duplicados
1. A pesquisa guarda cada oportunidade na base de dados com `fingerprint` único.
2. A oportunidade nova aparece como `pending` (por rever).
3. O administrador aprova; passa a `published`.
4. O botão Exportar gera um JSON com as publicadas ainda não exportadas.
5. Depois de iniciar o download, o navegador envia confirmação (`ack`) e os IDs ficam com `exported_at`.
6. Os registos continuam na base de dados e a impressão digital impede que reapareçam como novos. O histórico não é apagado.

Nota técnica: o navegador não consegue garantir que o utilizador guardou o ficheiro no dispositivo; o sistema confirma que o download foi iniciado pelo navegador. Se a confirmação falhar, os itens podem aparecer novamente na exportação seguinte, sem duplicar os registos na base de dados.

## Fontes e limites importantes
- `sources.json` é uma lista inicial de fontes. Acrescente apenas páginas oficiais ou fontes confiáveis e verifique se os seus termos permitem recolha automatizada.
- O rastreador inicial procura links cujo texto/endereço contenha palavras-chave. Sites com JavaScript pesado, CAPTCHA, login ou bloqueios podem não funcionar; para esses sites será necessário um conector/API/RSS específico.
- A extracção por IA pode cometer erros. Por segurança, `AUTO_PUBLISH=false` mantém os registos em revisão. Recomenda-se não activar publicação automática antes de validar a qualidade durante algum tempo.
- A data limite não é inferida: fica vazia quando a fonte não a informa.
- A imagem encontrada em `og:image` pode ser uma imagem genérica da página; confirme-a. O logótipo detectado pode ser apenas favicon. A interface e as notas identificam fallbacks, mas uma revisão humana é recomendada.
- O projecto não promete descobrir todas as oportunidades da Internet. A cobertura depende das fontes configuradas e da forma como cada site publica os seus anúncios.
